# EDAns - Extension lấy đáp án ED và TOEIC

## Cài đặt
1. Download [EDAns.zip](https://github.com/nvbangg/EDAns/releases) và giải nén
2. Mở trình duyệt và truy cập `chrome://extensions/`
2. Bật **Developer Mode**
3. Nhấn **Load unpacked** 
4. Chọn thư mục `EDAns`

## Hướng dẫn 
- Nhấn `Z` để tự động chọn và chuyển câu (dùng trong phần Explore và Practice)
- Nhấn `Space` để Chuyển câu (dùng trong phần Test)
- Đáp án tự động hiển thị sau khi chuyển câu bằng `Z`, `Space`
- Click `Get Answer` để hiển thị đáp án thủ công

## Follow me👀 and Star⭐ 
 **Follow👀:** [![Follow](https://img.shields.io/github/followers/nvbangg?label=Follow&style=social)](https://github.com/nvbangg) | **Star⭐:** [![Star](https://img.shields.io/github/stars/nvbangg/nvbangg-tools?style=social)](https://github.com/nvbangg/nvbangg-tools)

![Gif](https://raw.githubusercontent.com/nvbangg/nvbangg/main/data/star_follow.gif)

[![Visitors](https://api.visitorbadge.io/api/visitors?path=https%3A%2F%2Fgithub.com%2Fnvbangg%2FEDAns&countColor=%232ccce4)](https://visitorbadge.io/status?path=https%3A%2F%2Fgithub.com%2Fnvbangg%2FEDAns)